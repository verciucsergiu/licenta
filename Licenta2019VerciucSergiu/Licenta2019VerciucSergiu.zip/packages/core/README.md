# TYPENET

## Core package