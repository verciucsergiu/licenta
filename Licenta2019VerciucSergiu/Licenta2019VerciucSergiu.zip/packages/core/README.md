# TYPENET

## Core package