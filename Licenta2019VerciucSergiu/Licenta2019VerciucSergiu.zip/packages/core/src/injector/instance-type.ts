export type InstanceType = 'singleInstance' | 'scopedInstance' | 'transientInstance';
