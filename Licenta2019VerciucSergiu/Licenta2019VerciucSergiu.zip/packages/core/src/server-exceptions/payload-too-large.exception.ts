import { Exception } from './exception';

export class PayloadTooLargeException extends Exception {
}