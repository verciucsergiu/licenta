export class Exception {
    constructor(public message?: string) {
    }
}