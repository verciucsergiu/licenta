import { Exception } from './exception';

export class InternalServerException extends Exception {
}