import { Response } from './response';

export class Ok extends Response {
    public statusCode: number = 200;
}