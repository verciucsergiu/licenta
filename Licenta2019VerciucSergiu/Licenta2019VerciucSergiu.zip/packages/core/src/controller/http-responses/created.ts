import { Response } from './response';

export class Created extends Response {
    public statusCode: number = 201;
}