export interface ServerSettings {
    maxRequestSize: number;
    port: number;
}