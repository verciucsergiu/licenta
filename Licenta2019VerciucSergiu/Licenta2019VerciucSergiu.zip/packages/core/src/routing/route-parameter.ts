export interface RouteParameter {
    [name: string]: number;
}
