export const METADATA = {
    CONTROLLER: '__CONTROLLER__',
    MODULE: '__MODULE__',
    INJECTABLE: '__INJECTABLE__',
    MIDDLEWARE: '__MIDDLEWARE__'
};