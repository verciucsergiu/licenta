# @typenet/web-socket
Typenet web-socket package