export const webSocketMetadata = {
    hub: '__WSHUB__'
};
