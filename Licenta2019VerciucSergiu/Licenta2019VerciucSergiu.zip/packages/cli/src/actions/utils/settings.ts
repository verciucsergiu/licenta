export const settings = {
    boilerpalte: {
        git: "https://github.com/verciucsergiu/typenet-boilerplates.git",
        branch: "master"
    }
};
