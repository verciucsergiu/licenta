export interface ICommand {
    // empty on purpose
}