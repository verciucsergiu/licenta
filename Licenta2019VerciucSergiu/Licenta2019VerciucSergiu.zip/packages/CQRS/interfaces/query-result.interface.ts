export interface IQueryResult {
}