export interface IQueryResult {
}