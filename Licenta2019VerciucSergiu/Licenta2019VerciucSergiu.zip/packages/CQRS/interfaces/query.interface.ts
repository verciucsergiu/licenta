export interface IQuery {
    // empty on purpose
}