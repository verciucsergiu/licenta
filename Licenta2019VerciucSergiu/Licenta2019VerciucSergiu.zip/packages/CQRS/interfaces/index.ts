export * from './command.interface';
export * from './command-handler.interface';
export * from './query-handler.interface';
export * from './query-result.interface';
export * from './query.interface';