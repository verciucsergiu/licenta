export interface BaseCommandHandlerMetadata {
    commandType?: Function;
}