export interface BaseQueryHandlerMetadata {
    queryType?: Function;

    resultType: Function;
}