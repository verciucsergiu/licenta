export const messages = {
    welcome: ''
};