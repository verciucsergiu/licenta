export const messages = {
    welcome: ''
};